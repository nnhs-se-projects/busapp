# Bus App Browser Extension

This is a simple extension that just contains an iframe that shows the /extension page on the Bus App. There is some Javascript to resize the iframe to the content, but thats all this extension does.
